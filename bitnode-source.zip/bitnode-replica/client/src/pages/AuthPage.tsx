import { FormEvent, useState } from "react";
import { Link, useLocation } from "wouter";
import { ArrowRight, Loader2, ShieldCheck } from "lucide-react";
import { supabase } from "@/lib/supabaseClient";

export default function AuthPage() {
  const [, navigate] = useLocation();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("gentecash");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setError("");
    setMessage("");
    if (!supabase) return setError("Supabase no está configurado en este entorno.");
    if (!email.trim() || !email.includes("@")) return setError("Introduce un correo válido.");
    if (password.length < 8) return setError("La contraseña debe tener al menos 8 caracteres.");
    setLoading(true);
    const result = mode === "login"
      ? await supabase.auth.signInWithPassword({ email: email.trim(), password })
      : await supabase.auth.signUp({ email: email.trim(), password, options: { data: { username: username.trim() || "usuario" } } });
    setLoading(false);
    if (result.error) return setError(result.error.message);
    if (mode === "signup" && !result.data.session) {
      setMessage("Cuenta creada. Revisa tu correo para confirmar la dirección antes de iniciar sesión.");
      return;
    }
    navigate("/dashboard");
  };

  return <main className="auth-shell"><section className="auth-card"><Link className="auth-brand" href="/"><span className="auth-mark">⌬</span><span>bitnode<span>.</span></span></Link><div className="auth-kicker"><ShieldCheck size={15} /> AUTH / SUPABASE</div><h1>{mode === "login" ? "Entra a tu panel." : "Crea tu cuenta."}</h1><p>{mode === "login" ? "Accede a tus nodos, balances y movimientos verificados." : "Tu cuenta quedará vinculada a un usuario autenticado."}</p><form onSubmit={submit} noValidate>{mode === "signup" && <label>Usuario<input value={username} onChange={(event) => setUsername(event.target.value)} autoComplete="username" /></label>}<label>Correo electrónico<input type="email" value={email} onChange={(event) => setEmail(event.target.value)} autoComplete="email" /></label><label>Contraseña<input type="password" value={password} onChange={(event) => setPassword(event.target.value)} autoComplete={mode === "login" ? "current-password" : "new-password"} /></label>{error && <div className="form-error" role="alert">{error}</div>}{message && <div className="form-success" role="status">{message}</div>}<button className="dash-primary auth-submit" disabled={loading}>{loading ? <><Loader2 className="spin" size={16} /> Procesando</> : <>{mode === "login" ? "Iniciar sesión" : "Crear cuenta"} <ArrowRight size={16} /></>}</button></form><button className="auth-switch" onClick={() => { setMode(mode === "login" ? "signup" : "login"); setError(""); setMessage(""); }}>{mode === "login" ? "¿No tienes cuenta? Crear una" : "¿Ya tienes cuenta? Iniciar sesión"}</button><Link className="auth-back" href="/">← Volver a BitNode</Link></section></main>;
}
