import "dotenv/config";
import express from "express";
import helmet from "helmet";
import { createApiRateLimiter, createFinancialRateLimiter } from "../security";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { registerNowPaymentsRoutes } from "../nowpayments";
import { registerWithdrawalRoutes } from "../withdrawals";
import { registerCommissionRoutes } from "../commissions";
import { registerDepositRoutes } from "../deposits";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  app.disable("x-powered-by");
  app.set("trust proxy", 1);
  app.use(helmet({ contentSecurityPolicy: false }));
  const apiLimiter = createApiRateLimiter();
  const financialLimiter = createFinancialRateLimiter();
  app.use(express.json({ limit: "1mb" }));
  app.use(express.urlencoded({ limit: "64kb", extended: true }));
  app.use("/api", apiLimiter);
  app.use(["/api/deposits", "/api/withdrawals", "/api/contracts", "/api/commissions"], financialLimiter);
  registerStorageProxy(app);
  registerOAuthRoutes(app);
  registerNowPaymentsRoutes(app);
  registerWithdrawalRoutes(app);
  registerCommissionRoutes(app);
  registerDepositRoutes(app);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
